import requests
from lxml import html
import mysql.connector
from datetime import datetime

# データ抽出する
url = "https://finance.yahoo.com/quote/JPY=X"
headers = {"User-Agent": "Mozilla/5.0"}
response = requests.get(url, headers=headers)

tree = html.fromstring(response.content)
xpath = '//*[@id="nimbus-app"]/section/section/section/article/section[1]/div[2]/div[1]/section/div/section/div[1]/div[1]/span/text()'
result = tree.xpath(xpath)

if not result:
    print("❌ Xpathを探しなかった！")
    exit()

# 小数処理
rate_str = result[0].replace(',', '') 
rate = float(rate_str)

print(f"✅ 今の為替レートは：{rate} 円")

# データベースに入れる
try:
    conn = mysql.connector.connect(
        host="localhost",
        user="rezouser",
        password="Rezo_0000",
        database="diary_app" 
    )
    cursor = conn.cursor()

    insert_sql = "INSERT INTO exchange_rates (usd_to_jpy, timestamp) VALUES (%s, %s)"
    cursor.execute(insert_sql, (rate, datetime.now()))
    conn.commit()
    print("✅ 成功しました！")

except mysql.connector.Error as err:
    print(f"❌ データベース間違えた：{err}")

finally:
    if cursor:
        cursor.close()
    if conn:
        conn.close()
