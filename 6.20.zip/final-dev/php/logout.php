<?php
//＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
//　　　　　　　ログアウト機能
//＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊

//session設定初期化する
session_start();

session_unset();

session_destroy();

//ホームページにジャンプする
header("Location: index.php");
exit();
?>
