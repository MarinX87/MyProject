<?php
//＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
//          日経平均　折り線グラフ
//＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
//<h5><a href="rate5.php" style="text-decoration: none; color: inherit;">💱 為替</a></h5>
//<h5><a href="index5.php" style="text-decoration: none; color: inherit;">📈 日経平均</a></h5>
require 'config.php';
session_start();

//ログインチェック
//ログインしなかった（index.phpにジャンプする）
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) 
{
  header("Location: index.php");
  exit();
}

$userId = $_SESSION['user_id'] ?? "";

try
{
    $sql = "SELECT 
    DATE(timestamp) AS date,
    index_value
    FROM nikkei_index
    WHERE WEEKDAY(timestamp) BETWEEN 0 AND 4 
    GROUP BY DATE(timestamp)
    ORDER BY date;";

    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $index5 = $stmt->fetchAll();

    $raw = [];
    foreach($index5 as $rate)
    {
        $raw[] = $rate['index_value'];
    }

}
catch (Exception $e) 
{
    die("データベースエラー: " . htmlspecialchars($e->getMessage()));
}
 
?>


<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>日経平均折り線グラフ</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>


<body class="bg-light">
    <div class="container">
        <h1 class="mb-4 text-center">日経平均折り線グラフ</h1>
            <canvas id="lineChart"></canvas>
            <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

<canvas id="lineChart"></canvas>

<script>
    const data1 = <?php echo json_encode($raw); ?>;
    const ctx = document.getElementById('lineChart').getContext('2d');
    const lineChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: ['月曜日', '火曜日', '水曜日', '木曜日', '金曜日'],
            datasets: [{
                label: 'ポイント',
                data: data1,
                borderColor: 'rgba(75, 192, 192, 1)',
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                tension: 0.4,
                fill: true,
                pointRadius: 5,
                pointHoverRadius: 7
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: '今週日経平均指数'
                }
            },
            scales: {
                y: {
                    beginAtZero: false 
                }
            }
        }
    });
</script>

    </div>
</body>
</html>



