<?php
//＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
//              編集機能
//＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊＊
require 'config.php';
session_start();

// ログインチェック
//ログインしなかった（index.phpにジャンプする）
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) 
{
  header("Location: index.php");
  exit();
}

$userId = $_SESSION['user_id'] ?? "";


// 更新ある場合の処理
if ($_SERVER['REQUEST_METHOD'] === 'POST') 
{
  
  $id = $_POST['id'];
  $content = trim($_POST['content']);

  if ($id && $content && $userId) 
  {
    try 
    {
      $sql  = "UPDATE diaries SET content = ? WHERE id = ? AND user_id = ?";
      $stmt = $pdo->prepare($sql);
      $stmt->execute([$content, $id, $userId]);
      header("Location: diary.php");
      exit();
    }

    catch (Exception $e) 
    {
      die("データベースエラー: " . htmlspecialchars($e->getMessage()));
    }
  }

} 
else 
{
  // 編集画面表示処理
  $id = $_GET['id'] ?? "";

  try 
  {
    $stmt = $pdo->prepare("SELECT * FROM diaries WHERE id = ? AND user_id = ?");
    $stmt->execute([$id, $userId]);
    $entries = $stmt->fetch();

    if (!$entries) 
    {
      echo "日記が見つかりません。";
      exit();
    }

  } 
  catch (Exception $e) 
  {
    die("データベースエラー: " . htmlspecialchars($e->getMessage()));
  }
}
?>


<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>編集</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
  <div class="container mt-5">
    <h1 class="mb-4 text-center">日記編集</h1>
    <form action="edit.php" method="post">
      <input type="hidden" name="id" value="<?= htmlspecialchars($entries['id']) ?>">
      <div class="mb-3">
        <textarea name="content" class="form-control" rows="10"><?= htmlspecialchars($entries['content']) ?></textarea>
      </div>
      <button type="submit" class="btn btn-primary">更新する</button>
      <a href="diary.php" class="btn btn-secondary">戻る</a>
    </form>
  </div>
</body>
</html>

