import requests
from lxml import html
import re
import mysql.connector
from datetime import datetime

# 天気情報を取得
url = "https://www.accuweather.com/ja/jp/tokyo/226396/weather-forecast/226396"
headers = {"User-Agent": "Mozilla/5.0"}
response = requests.get(url, headers=headers)
tree = html.fromstring(response.content)

# XPath定義
xpaths = {
    "min_temp": '/html/body/div[1]/div[7]/div[1]/div[1]/a[1]/div[2]/div[1]/div[1]/div/div[1]/text()',
    "max_temp_raw": '/html/body/div[1]/div[7]/div[1]/div[1]/a[1]/div[2]/div[1]/div[1]/div/div[2]//text()',
    "weather": '/html/body/div[1]/div[7]/div[1]/div[1]/a[1]/div[2]/div[1]/div[2]/span[1]/text()'
}

# データ抽出と整形
min_temp_raw = tree.xpath(xpaths["min_temp"])
max_temp_raw = tree.xpath(xpaths["max_temp_raw"])
weather_raw = tree.xpath(xpaths["weather"])

min_str = min_temp_raw[0].strip() if min_temp_raw else "N/A"
max_str = "N/A"
for text in max_temp_raw:
    matches = re.findall(r'\d+°', text)
    if matches:
        max_str = matches[0]
        break
weather_str = weather_raw[0].strip() if weather_raw else "N/A"

# °記号を除いて数値化
def to_decimal(temp_str):
    return float(temp_str.replace('°', '')) if temp_str != "N/A" else None

min_temp_val = to_decimal(min_str)
max_temp_val = to_decimal(max_str)

# 現在時刻
timestamp = datetime.now()

# MySQL接続情報（あなたの環境に合わせて修正してください）
conn = mysql.connector.connect(
    host="localhost",
    user="rezouser",
    password="Rezo_0000",
    database="diary_app"
)

cursor = conn.cursor()

# INSERT文実行
insert_sql = """
INSERT INTO weather_data (min_temp, max_temp, weather, timestamp)
VALUES (%s, %s, %s, %s)
"""
cursor.execute(insert_sql, (min_temp_val, max_temp_val, weather_str, timestamp))
conn.commit()

# 終了処理
cursor.close()
conn.close()

print("データを保存しました：", min_temp_val, max_temp_val, weather_str, timestamp)
