# -*- coding: utf-8 -*-
import requests
from lxml import html
from datetime import datetime

url = "https://finance.yahoo.com/quote/JPY=X"
headers = {"User-Agent": "Mozilla/5.0"}
response = requests.get(url, headers=headers)

tree = html.fromstring(response.content)
xpath = '//*[@id="nimbus-app"]/section/section/section/article/section[1]/div[2]/div[1]/section/div/section/div[1]/div[1]/span/text()'
result = tree.xpath(xpath)

if not result:
    print("為替レートの取得に失敗しました")
    exit()

rate_str = result[0].replace(',', '')
rate = float(rate_str)
print(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}：1ドル = {rate} 円")
