<?php
require 'config.php';

$entries = [];
$keyword = $_GET['q'] ?? '';

try 
{
  //キーワードを検索する
  if ($keyword) 
  {
    $sql = "SELECT * FROM diaries WHERE content LIKE ? ORDER BY id DESC";
    $stmt = $pdo->prepare($sql);
    $stmt->execute(['%' . $keyword . '%']);
    $entries = $stmt->fetchAll();
  } 
  else 
  {
    $entries = $pdo->query("SELECT * FROM diaries ORDER BY id DESC")->fetchAll();
  }

  //日記をデータベースに入れる
  if ($_SERVER['REQUEST_METHOD'] === 'POST') 
  {
    $content = $_POST['content'];
    if ($content) 
    {
      $sql = "INSERT INTO diaries (content) VALUES (?)";
      $stmt = $pdo->prepare($sql);
      $stmt->execute([$content]);

      //二重提出を防止するため
      header("Location: diary.php");
      exit();
    }
  }
} 
catch (Exception $e) 
{
  die("データベースエラー: " . htmlspecialchars($e->getMessage()));
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>Diary</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; }
    .navbar-brand { font-size: 2rem; font-weight: bold; letter-spacing: 2px; }
    .entry-card {
      background: white;
      border-left: 5px solid #0d6efd;
      border-radius: 0.5rem;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
      padding: 1rem;
      margin-bottom: 1.5rem;
    }
    textarea.form-control { resize: none; }
  </style>
</head>
<body>

<!-- タイトル -->
<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <div class="container">
    <span class="navbar-brand">Diary</span>
    <a href="news.php" class="btn btn-outline-light ms-auto">News</a>
  </div>
</nav>

<!-- 内容 -->
<div class="container mt-4">

  <!-- 検索フォーム -->
  <form method="get" class="mb-4">
    <div class="input-group">
      <input type="text" name="q" class="form-control" placeholder="何探したい..." value="<?= htmlspecialchars($keyword) ?>">
      <button class="btn btn-outline-secondary" type="submit">検索</button>
    </div>
  </form>

  <!-- 投稿フォーム -->
  <?php if ($keyword): ?>
    <p class="text-muted">🔍 キーワード： “<strong><?= htmlspecialchars($keyword) ?></strong>” の検索結果：</p>
  <?php else: ?>
    <form method="post" class="mb-4">
      <textarea class="form-control mb-2" name="content" rows="3" placeholder="メモ・日記を書いてください..."></textarea>
      <button class="btn btn-primary">提出</button>
    </form>
  <?php endif; ?>

  <!-- 日報リスト -->
  <?php if (empty($entries)): ?>
    <p class="text-muted">📭 データが見つかりません。</p>
  <?php else: ?>
    <?php foreach ($entries as $entry): ?>
      <form action="update.php" method="post" class="entry-card">
        <input type="hidden" name="id" value="<?= $entry['id'] ?>">

        <!-- 日記表示 -->
        <div class="form-control mb-2 bg-light" style="white-space: pre-wrap;">
          <?= nl2br(htmlspecialchars($entry['content'])) ?>
        </div>

        <!-- 編集機能 -->
        <textarea name="content" rows="3" class="form-control mb-2 d-none"><?= htmlspecialchars($entry['content']) ?></textarea>

        <div class="d-flex justify-content-between align-items-center">
          <small class="text-muted">🕒 <?= $entry['created_at'] ?></small>
          <div>
            <button type="button" class="btn btn-outline-secondary btn-sm me-1 btn-edit">編集</button>
            <button type="submit" class="btn btn-success btn-sm d-none btn-save">更新</button>
            <button type="button" class="btn btn-danger btn-sm"
                    data-bs-toggle="modal"
                    data-bs-target="#deleteModal"
                    data-entry-id="<?= $entry['id'] ?>">削除</button>
          </div>
        </div>
      </form>
    <?php endforeach; ?>
  <?php endif; ?>
</div>

<!-- 削除確認モーダル -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-danger text-white">
        <h5 class="modal-title" id="deleteModalLabel">削除の確認</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="閉じる"></button>
      </div>
      <div class="modal-body">
        この日報を削除してもよろしいですか？
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">キャンセル</button>
        <a id="confirmDeleteBtn" href="#" class="btn btn-danger">はい、削除</a>
      </div>
    </div>
  </div>
</div>

<!-- JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () 
{
  // 削除処理
  const deleteModal = document.getElementById('deleteModal');
  const confirmBtn = document.getElementById('confirmDeleteBtn');
  deleteModal.addEventListener('show.bs.modal', function (event) 
  {
    const button = event.relatedTarget;
    const entryId = button.getAttribute('data-entry-id');
    confirmBtn.href = `delete.php?id=${entryId}`;
  });

  // 編集切替
  document.querySelectorAll('.btn-edit').forEach(btn => 
  {
    btn.addEventListener('click', function () 
    {
      const form = btn.closest('form');
      const view = form.querySelector('.form-control.bg-light');
      const textarea = form.querySelector('textarea');
      const saveBtn = form.querySelector('.btn-save');

      view.classList.add('d-none');
      textarea.classList.remove('d-none');
      saveBtn.classList.remove('d-none');
      textarea.focus();
    });
  });
});
</script>
</body>
</html>
