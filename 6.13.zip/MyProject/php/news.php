<!doctype html>
<html lang="ja">
<head>
  <meta charset="UTF-8">
  <title>News & Diary</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background-color: #f8f9fa; }
    .navbar-brand { font-size: 2rem; font-weight: bold; letter-spacing: 2px; }
    .info-bar 
    {
      background: linear-gradient(to right, #6dd5fa, #2980b9);
      color: white; padding: 0.75rem 1rem; border-radius: 0.5rem;
      margin-top: 1rem;
    }
    .info-card 
    {
      background: white; color: black; border-left: 5px solid #198754;
      box-shadow: 0 2px 6px rgba(0,0,0,0.05);
      padding: 1rem;
      border-radius: 0.5rem;
      margin-top: 1rem;
    }
    .blog-post img 
    {
      max-width: 100%;
      border-radius: 8px;
    }
    .blog-post 
    {
      background: white;
      border-radius: 0.5rem;
      box-shadow: 0 2px 8px rgba(0,0,0,0.05);
      padding: 1rem;
      margin-bottom: 1.5rem;
    }
  </style>
</head>
<body>

  <!-- ナビゲーションバー -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">
      <span class="navbar-brand">News and Diary</span>
      <a href="diary.php" class="btn btn-outline-light ms-auto">日報</a>
    </div>
  </nav>

  <!-- メインコンテンツ -->
  <div class="container mt-3">

    <!-- 天気予報 -->
    <div class="info-bar text-center">
      🌤️ 天気予報：雨 20ー24℃
    </div>

    <!-- カード型：日経平均と為替 -->
    <div class="row mt-3">
      <div class="col-12 col-md-6">
        <div class="info-card">
          <h5>📈 日経平均</h5>
          <p>日経平均株価：32,400.15（+1.12%）</p>
        </div>
      </div>
      <div class="col-12 col-md-6">
        <div class="info-card">
          <h5>💱 為替</h5>
          <p>1 ドル = 144.94 円</p>
        </div>
      </div>
    </div>
        <div class="row mt-3">
      <div class="col-12 col-md-6">
        <div class="info-card">
          <h5>📈 丸紅株式会社ー株価</h5>
          <p>2980 円</p>
        </div>
      </div>
      <div class="col-12 col-md-6">
        <div class="info-card">
          <h5>📈 トヨタ自動車ー株価</h5>
          <p>2980 円</p>
        </div>
      </div>
    </div>

    <!-- ニュース分類ナビ -->
    <ul class="nav nav-tabs mt-4" id="newsTab" role="tablist">
      <li class="nav-item" role="presentation">
        <button class="nav-link active" id="top-tab" data-bs-toggle="tab" data-bs-target="#top" type="button" role="tab">📰 トップニュース</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="economy-tab" data-bs-toggle="tab" data-bs-target="#economy" type="button" role="tab">💹 経済ニュース</button>
      </li>
      <li class="nav-item" role="presentation">
        <button class="nav-link" id="sports-tab" data-bs-toggle="tab" data-bs-target="#sports" type="button" role="tab">⚽ スポーツ</button>
      </li>
    </ul>

    <!-- ニュース内容 -->
    <div class="tab-content" id="newsTabContent">
      <!-- トップニュース -->
      <div class="tab-pane fade show active" id="top" role="tabpanel">
        <div class="blog-post row align-items-center mt-3">
          <div class="col-12 col-md-5">
            <img src="https://source.unsplash.com/600x400/?headline" alt="トップニュース画像">
          </div>
          <div class="col-12 col-md-7">
            <h3>速報：最新ニュース</h3>
            <p>ここにトップニュースの詳細を記載します。</p>
          </div>
        </div>
      </div>

      <!-- 経済ニュース -->
      <div class="tab-pane fade" id="economy" role="tabpanel">
        <div class="blog-post row align-items-center mt-3">
          <div class="col-12 col-md-5">
            <img src="https://source.unsplash.com/600x400/?business" alt="経済ニュース画像">
          </div>
          <div class="col-12 col-md-7">
            <h3>円高が進行中</h3>
            <p>為替市場における動きとその影響について。</p>
          </div>
        </div>
      </div>

      <!-- スポーツ -->
      <div class="tab-pane fade" id="sports" role="tabpanel">
        <div class="blog-post row align-items-center mt-3">
          <div class="col-12 col-md-5">
            <img src="https://source.unsplash.com/600x400/?sports" alt="スポーツニュース画像">
          </div>
          <div class="col-12 col-md-7">
            <h3>サッカー日本代表が勝利！</h3>
            <p>ワールドカップ予選での試合結果と選手のコメント。</p>
          </div>
        </div>
      </div>
    </div>

  </div>

  <!-- Bootstrap Script -->
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>

</body>
</html>
