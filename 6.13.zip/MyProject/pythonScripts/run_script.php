<?php
// Python ファイル
$pythonScript = "C:\\xampp\\htdocs\\php_sample\\MyProject\\pythonScripts\\get_rate.py";

// Python 実行
$command = escapeshellcmd("python " . $pythonScript);
$output = shell_exec($command);

// 結果出力
if ($output === null) 
{
    echo "Python スクリプト実行失敗";
} 
else 
{
    echo $output;
}
?>
